<?php

/*
 * RfiInitLang custom validators
 */

namespace Aef\Bundle\Hermes\RfiBundle\Command;

use Sensio\Bundle\GeneratorBundle\Command\Validators;

/**
 * Validator functions.
 */
class RfiInitLangValidators extends Validators
{

    /**
     * Validates bundle lang
     *
     * @param $lang
     * @return mixed
     * @throws \InvalidArgumentException
     */
    public static function validateBundleLang($lang)
    {
        $regex = "/^[A-Z][a-z]+$/";
        if (!preg_match($regex, $lang)) {
            throw new \InvalidArgumentException(sprintf('The lang must match %s', $regex));
        }

        return $lang;
    }

    /**
     * Validates bundle path
     *
     * @param $namespace
     * @param $bundle
     * @param $dir
     * @return string
     * @throws \InvalidArgumentException
     */
    public static function validateBundlePath($namespace, $bundle, $dir)
    {
        $path = rtrim($dir, '/').'/'.trim(strtr($namespace, '\\', '/'), '/').'/';
        $fullPath = $path.$bundle.'.php';
        if (!is_dir($path)) {
            throw new \InvalidArgumentException(sprintf('directory %s does not exists', $path));
        }
        if (!is_file($fullPath)) {
            throw new \InvalidArgumentException(sprintf('file %s does not exists', $fullPath));
        }
        return $fullPath;
    }

}
