<?php

/*
 * Extract from GenerateBundleCommand to only init (enable) an already generated bundle
 * appKernel & routing
 *
 *
 * use silent: app/console rfi:init-lang --lang=English --no-interaction
 */

namespace Aef\Bundle\Hermes\RfiBundle\Command;

use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Output\Output;
use Symfony\Component\HttpKernel\KernelInterface;
use Sensio\Bundle\GeneratorBundle\Command\GeneratorCommand;
use Sensio\Bundle\GeneratorBundle\Command\Validators;
use Sensio\Bundle\GeneratorBundle\Generator\BundleGenerator;
use Sensio\Bundle\GeneratorBundle\Manipulator\KernelManipulator;
use Sensio\Bundle\GeneratorBundle\Manipulator\RoutingManipulator;
use Sensio\Bundle\GeneratorBundle\Command\Helper\DialogHelper;

class RfiInitLangCommand extends GeneratorCommand
{
    const RFI_LANG_NAMESPACE    = 'Aef/Bundle/Hermes/Rfi%sBundle';
    const RFI_LANG_NAME         = 'AefHermesRfi%sBundle';
    const RFI_LANG_DIR          = 'src';
    const RFI_LANG_FORMAT       = 'yml';

    protected $lang             = null;
    protected $namespace        = null;
    protected $name             = null;

    /**
     * @see Command
     */
    protected function configure()
    {
        $this
            ->setDefinition(array(
                new InputOption('lang', '', InputOption::VALUE_REQUIRED, 'The lang of the bundle to init'),
            ))
            ->setDescription('init a rfi lang bundle')
            ->setHelp(<<<EOT
The <info>rfi:init-lang</info> command helps you init rfi lang bundles.

By default, the command interacts with the developer to tweak the init.
Any passed option will be used as a default value for the interaction
<comment>--lang</comment> is the only one needed:

<info>php app/console rfi:init-lang --lang=English</info>

If you want to disable any user interaction, use <comment>--no-interaction</comment> but don't forget to pass all needed options:

<info>php app/console rfi:init-lang --lang=English --no-interaction</info>

Note that the bundle you try to init should already exists in src/,
the namespace and name should respect Symfony 2 standards,
namespace: Aef\Bundle\Hermes\Rfi[LANG]Bundle
name: AefHermesRfi[LANG]Bundle
and should have been generated with yml config format
EOT
            )
            ->setName('rfi:init-lang')
        ;
    }

    /**
     * @see Command
     *
     * @throws \InvalidArgumentException When namespace doesn't end with Bundle
     * @throws \RuntimeException         When bundle can't be executed
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $dialog = $this->getDialogHelper();

        if ($input->isInteractive()) {
            if (!$dialog->askConfirmation($output, $dialog->getQuestion('Do you confirm init', 'yes', '?'), true)) {
                $output->writeln('<error>Command aborted</error>');

                return 1;
            }
        }

        foreach (array('lang') as $option) {
            if (null === $input->getOption($option)) {
                throw new \RuntimeException(sprintf('The "%s" option must be provided.', $option));
            }
        }

        $this->lang = RfiInitLangValidators::validateBundleLang($input->getOption('lang'));
        $this->namespace = sprintf(self::RFI_LANG_NAMESPACE, $this->lang);
        $this->name = sprintf(self::RFI_LANG_NAME, $this->lang);

        $namespace = Validators::validateBundleNamespace($this->namespace);
        if (!$bundle = $this->name) {
            $bundle = strtr($namespace, array('\\' => ''));
        }
        $bundle = Validators::validateBundleName($bundle);
        $dir = Validators::validateTargetDir(self::RFI_LANG_DIR, $bundle, $namespace);
        $format = Validators::validateFormat(self::RFI_LANG_FORMAT);

        $dialog->writeSection($output, 'Bundle init');

        if (!$this->getContainer()->get('filesystem')->isAbsolutePath($dir)) {
            $dir = getcwd().'/'.$dir;
        }

        /*$generator = $this->getGenerator();
        $generator->generate($namespace, $bundle, $dir, $format, $structure);*/
        try {
            RfiInitLangValidators::validateBundlePath($namespace, $bundle, $dir);
        } catch (\Exception $error) {
            $output->writeln($dialog->getHelperSet()->get('formatter')->formatBlock($error->getMessage(), 'error'));

            return 2;
        }

        $output->writeln('Initializing the bundle: <info>OK</info>');

        $errors = array();
        $runner = $dialog->getRunner($output, $errors);

        // check that the namespace is already autoloaded
        $runner($this->checkAutoloader($output, $namespace, $bundle, $dir));

        // register the bundle in the Kernel class
        $runner($this->updateKernel($dialog, $input, $output, $this->getContainer()->get('kernel'), $namespace, $bundle));

        // routing
        $runner($this->updateRouting($dialog, $input, $output, $bundle, $format));

        $dialog->writeGeneratorSummary($output, $errors);
    }

    protected function interact(InputInterface $input, OutputInterface $output)
    {
        $dialog = $this->getDialogHelper();
        $dialog->writeSection($output, 'Welcome to the RFI init-lang command');

        // lang
        $this->lang = null;
        try {
            $this->lang = $input->getOption('lang') ? RfiInitLangValidators::validateBundleLang($input->getOption('lang')) : null;
        } catch (\Exception $error) {
            $output->writeln($dialog->getHelperSet()->get('formatter')->formatBlock($error->getMessage(), 'error'));
        }

        if (null === $this->lang) {
            $output->writeln(array(
                '',
                'You must provide a lang parameter eg. English',
                '',
            ));

            $this->lang = $dialog->askAndValidate(
                $output,
                $dialog->getQuestion(
                    'Bundle lang',
                    $input->getOption('lang')
                ),
                array('Aef\Bundle\Hermes\RfiBundle\Command\RfiInitLangValidators', 'validateBundleLang'),
                false,
                $input->getOption('lang')
            );
            $input->setOption('lang', $this->lang);
        }

        $this->namespace = sprintf(self::RFI_LANG_NAMESPACE, $this->lang);
        $this->name = sprintf(self::RFI_LANG_NAME, $this->lang);

        // namespace
        $namespace = null;
        try {
            $namespace = Validators::validateBundleNamespace($this->namespace);
        } catch (\Exception $error) {
            $output->writeln($dialog->getHelperSet()->get('formatter')->formatBlock($error->getMessage(), 'error'));
        }

        // bundle name
        $bundle = null;
        try {
            $bundle = Validators::validateBundleName($this->name);
        } catch (\Exception $error) {
            $output->writeln($dialog->getHelperSet()->get('formatter')->formatBlock($error->getMessage(), 'error'));
        }

        // target dir
        $dir = null;
        try {
            $dir = Validators::validateTargetDir(self::RFI_LANG_DIR, $bundle, $namespace);
        } catch (\Exception $error) {
            $output->writeln($dialog->getHelperSet()->get('formatter')->formatBlock($error->getMessage(), 'error'));
        }

        // format
        $format = null;
        try {
            $format = Validators::validateFormat(self::RFI_LANG_FORMAT);
        } catch (\Exception $error) {
            $output->writeln($dialog->getHelperSet()->get('formatter')->formatBlock($error->getMessage(), 'error'));
        }

        // summary
        $output->writeln(array(
            '',
            $this->getHelper('formatter')->formatBlock('Summary before init', 'bg=blue;fg=white', true),
            '',
            sprintf("You are going to init a \"<info>%s\\%s</info>\" bundle\nin \"<info>%s</info>\" using the \"<info>%s</info>\" format.", $namespace, $bundle, $dir, $format),
            '',
        ));
    }

    protected function checkAutoloader(OutputInterface $output, $namespace, $bundle, $dir)
    {
        $output->write('Checking that the bundle is autoloaded: ');
        if (!class_exists($namespace.'\\'.$bundle)) {
            return array(
                '- Edit the <comment>composer.json</comment> file and register the bundle',
                '  namespace in the "autoload" section:',
                '',
            );
        }
    }

    protected function updateKernel(DialogHelper $dialog, InputInterface $input, OutputInterface $output, KernelInterface $kernel, $namespace, $bundle)
    {
        $auto = true;
        if ($input->isInteractive()) {
            $auto = $dialog->askConfirmation($output, $dialog->getQuestion('Confirm automatic update of your Kernel', 'yes', '?'), true);
        }

        $output->write('Enabling the bundle inside the Kernel: ');
        $manip = new KernelManipulator($kernel);
        try {
            $ret = $auto ? $manip->addBundle($namespace.'\\'.$bundle) : false;

            if (!$ret) {
                $reflected = new \ReflectionObject($kernel);

                return array(
                    sprintf('- Edit <comment>%s</comment>', $reflected->getFilename()),
                    '  and add the following bundle in the <comment>AppKernel::registerBundles()</comment> method:',
                    '',
                    sprintf('    <comment>new %s(),</comment>', $namespace.'\\'.$bundle),
                    '',
                );
            }
        } catch (\RuntimeException $e) {
            return array(
                sprintf('Bundle <comment>%s</comment> is already defined in <comment>AppKernel::registerBundles()</comment>.', $namespace.'\\'.$bundle),
                '',
            );
        }
    }

    protected function updateRouting(DialogHelper $dialog, InputInterface $input, OutputInterface $output, $bundle, $format)
    {
        $auto = true;
        if ($input->isInteractive()) {
            $auto = $dialog->askConfirmation($output, $dialog->getQuestion('Confirm automatic update of the Routing', 'yes', '?'), true);
        }

        $output->write('Importing the bundle routing resource: ');
        $routing = new RoutingManipulator($this->getContainer()->getParameter('kernel.root_dir').'/config/routing.yml');
        try {
            $ret = $auto ? $routing->addResource($bundle, $format) : false;
            if (!$ret) {
                if ('annotation' === $format) {
                    $help = sprintf("        <comment>resource: \"@%s/Controller/\"</comment>\n        <comment>type:     annotation</comment>\n", $bundle);
                } else {
                    $help = sprintf("        <comment>resource: \"@%s/Resources/config/routing.%s\"</comment>\n", $bundle, $format);
                }
                $help .= "        <comment>prefix:   /</comment>\n";

                return array(
                    '- Import the bundle\'s routing resource in the app main routing file:',
                    '',
                    sprintf('    <comment>%s:</comment>', $bundle),
                    $help,
                    '',
                );
            }
        } catch (\RuntimeException $e) {
            return array(
                sprintf('Bundle <comment>%s</comment> is already imported.', $bundle),
                '',
            );
        }
    }

    protected function createGenerator()
    {
        return new BundleGenerator($this->getContainer()->get('filesystem'));
    }
}
